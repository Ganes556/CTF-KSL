module.exports = {
	homeRouter: require('./home'),
	userRouter: require('./user'),
}
